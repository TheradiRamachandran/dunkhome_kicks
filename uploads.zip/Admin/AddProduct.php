<?php
declare(strict_types=1);
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../session.php';
requireAdmin();

$adminEmail = (string) ($_SESSION['admin_email'] ?? 'Administrator');
$emailName = explode('@', $adminEmail)[0] ?? '';
$adminInitials = strtoupper(substr((string) (preg_replace('/[^a-zA-Z0-9]/', '', $emailName) ?: 'AD'), 0, 2));

$categories = [];
$categoryResult = $conn->query('SELECT name FROM categories WHERE is_active = 1 ORDER BY name');
if ($categoryResult) {
    while ($categoryRow = $categoryResult->fetch_assoc()) {
        $categories[] = (string) $categoryRow['name'];
    }
}

$message=''; $messageType='error';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $name=trim((string)($_POST['name']??''));
    $category=trim((string)($_POST['category']??''));
    $price=(float)($_POST['price']??0);
    $description=trim((string)($_POST['description']??''));
    if ($name==='' || $category==='' || $price<=0) $message='Please enter product name, category and a valid price.';
    elseif (!isset($_FILES['photo1'],$_FILES['photo2'],$_FILES['photo3'])) $message='Please select all 3 product photos.';
    else {
        $files=[$_FILES['photo1'],$_FILES['photo2'],$_FILES['photo3']]; $paths=[]; $ok=true;
        $allowed=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
        foreach($files as $file){
            if(($file['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK || (int)$file['size']>5*1024*1024 || @getimagesize($file['tmp_name'])===false){$ok=false;break;}
            $mime=(new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
            if(!isset($allowed[$mime])){$ok=false;break;}
            $filename=bin2hex(random_bytes(12)).'.'.$allowed[$mime];
            $destination=__DIR__.'/../uploads/products/'.$filename;
            if(!is_dir(dirname($destination)) && !mkdir(dirname($destination),0775,true)){$ok=false;break;}
            if(!move_uploaded_file($file['tmp_name'],$destination)){$ok=false;break;}
            $paths[]='uploads/products/'.$filename;
        }
        if(!$ok || count($paths)!==3){ foreach($paths as $p) @unlink(__DIR__.'/../'.$p); $message='Each photo must be JPG, PNG or WEBP and no larger than 5 MB.'; }
        else {
            $stmt=$conn->prepare('INSERT INTO products (name,category,price,description,image1,image2,image3) VALUES (?,?,?,?,?,?,?)');
            $stmt->bind_param('ssdssss',$name,$category,$price,$description,$paths[0],$paths[1],$paths[2]);
            if($stmt->execute()){ $message='Product added successfully.'; $messageType='success'; }
            else { foreach($paths as $p) @unlink(__DIR__.'/../'.$p); $message='Unable to add the product. Please try again.'; }
            $stmt->close();
        }
    }
}
define('ADD_PRODUCT_VIEW', true);
require __DIR__ . '/AddProductView.php';
exit;
?>
<!DOCTYPE html><html lang="en"><head>
<?php require __DIR__ . '/../includes/favicon.php'; ?><base href="<?= h(appBaseUrl()) ?>"><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><meta name="theme-color" content="#07100d"><title>Add Product | DunkHome Kicks</title><link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"><link rel="stylesheet" href="assets/dunkhome-ui.css?v=20261003-theme2"><link rel="stylesheet" href="assets/admin-pages.css?v=20261003-theme2"><link rel="stylesheet" href="assets/admin-navigation.css?v=20261003-theme1"><style>
:root{--bg:#07100d;--panel:rgba(14,29,24,.88);--white:#f8faf8;--muted:#9baba3;--line:rgba(255,255,255,.1);--green:#79e6aa;--orange:#ff9a62}*{box-sizing:border-box}body{margin:0;min-height:100vh;color:var(--white);font-family:"DM Sans",sans-serif;background:radial-gradient(circle at 8% 7%,rgba(121,230,170,.13),transparent 27%),radial-gradient(circle at 92% 82%,rgba(255,154,98,.08),transparent 23%),linear-gradient(135deg,#06100d,#0a1713 50%,#06100d)}a{color:inherit;text-decoration:none}.wrap{width:min(1120px,calc(100% - 34px));margin:auto}.top{min-height:88px;display:flex;align-items:center;justify-content:space-between;gap:18px}.brand{display:flex;align-items:center;gap:12px;font-weight:800;letter-spacing:.12em;text-transform:uppercase}.brand img{width:43px;height:43px;border-radius:13px;object-fit:cover;border:1px solid var(--line)}.brand span{color:var(--green)}.links{display:flex;gap:10px;align-items:center}.links a{padding:10px 13px;border:1px solid transparent;border-radius:11px;color:var(--muted)}.links a:hover{border-color:var(--line);color:var(--white)}main{padding:34px 0 70px}.shell{background:var(--panel);border:1px solid var(--line);border-radius:26px;box-shadow:0 35px 100px rgba(0,0,0,.4);backdrop-filter:blur(22px);padding:34px}.eyebrow{color:var(--green);font-size:11px;font-weight:800;letter-spacing:.16em;text-transform:uppercase}.title{font-family:"Playfair Display",serif;font-size:42px;margin:8px 0}.sub{color:var(--muted);max-width:680px;line-height:1.7}.message{padding:13px 15px;border-radius:12px;margin:20px 0;border:1px solid rgba(255,123,123,.2);color:#ffb0b0;background:rgba(255,123,123,.08)}.message.success{color:#9ff0bd;background:rgba(121,230,170,.08);border-color:rgba(121,230,170,.2)}.grid{display:grid;grid-template-columns:1fr 1fr;gap:20px}.field{display:flex;flex-direction:column;gap:8px}.field.full{grid-column:1/-1}.field label{font-size:12px;font-weight:800;color:#dfeae5}.field input,.field select,.field textarea{width:100%;border:1px solid var(--line);border-radius:13px;background:rgba(0,0,0,.18);color:var(--white);padding:14px 15px;outline:none}.field textarea{min-height:130px;resize:vertical}.field input:focus,.field select:focus,.field textarea:focus{border-color:rgba(121,230,170,.5);box-shadow:0 0 0 4px rgba(121,230,170,.06)}.photos{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;grid-column:1/-1}.photo{padding:18px;border:1px dashed rgba(121,230,170,.25);border-radius:16px;background:rgba(121,230,170,.03)}.photo label{display:block;margin-bottom:9px;font-weight:800;font-size:12px}.photo input{width:100%}.actions{display:flex;gap:12px;margin-top:22px}.btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;padding:13px 18px;border-radius:12px;font-weight:800;border:1px solid var(--line);cursor:pointer}.primary{background:linear-gradient(135deg,#4ade80,#22c55e);color:#041008;border:0}.secondary{background:rgba(255,255,255,.035)}@media(max-width:760px){.grid,.photos{grid-template-columns:1fr}.field.full{grid-column:auto}.photos{grid-column:auto}.links{display:none}.shell{padding:22px}.title{font-size:34px}}
</style></head><body><div class="wrap"><header class="top"><a class="brand" href="index.php"><img src="image/logo.jpg" alt="DunkHome Kicks"><div>dunkhome_<span>kicks</span></div></a><nav class="links admin-nav-links"><?php require __DIR__ . '/../includes/nav.php'; ?></nav></header><main><section class="shell"><div class="eyebrow">Administration · Product Management</div><h1 class="title">Add product</h1><p class="sub">Add a product with three gallery photos. Quantity is intentionally not included in this form or database.</p><?php if($message): ?><div class="message <?= $messageType==='success'?'success':'' ?>"><?= h($message) ?></div><?php endif; ?><form method="post" enctype="multipart/form-data" novalidate><div class="grid"><div class="field"><label for="name">Product name</label><input id="name" name="name" required maxlength="180"></div><div class="field"><label for="category">Category</label><select id="category" name="category" required><option value="">Select category</option><?php foreach($categories as $categoryOption): ?><option value="<?= h($categoryOption) ?>"><?= h($categoryOption) ?></option><?php endforeach; ?><?php if(!$categories): ?><option disabled>No active categories</option><?php endif; ?></select></div><div class="field"><label for="price">Price</label><input id="price" name="price" type="number" min="0.01" step="0.01" required></div><div class="field full"><label for="description">Description</label><textarea id="description" name="description" maxlength="5000" placeholder="Describe the product..."></textarea></div><div class="photos"><div class="photo"><label for="photo1">Photo 1</label><input id="photo1" name="photo1" type="file" accept="image/jpeg,image/png,image/webp" required></div><div class="photo"><label for="photo2">Photo 2</label><input id="photo2" name="photo2" type="file" accept="image/jpeg,image/png,image/webp" required></div><div class="photo"><label for="photo3">Photo 3</label><input id="photo3" name="photo3" type="file" accept="image/jpeg,image/png,image/webp" required></div></div></div><div class="actions"><button class="btn primary" type="submit"><i class="fa-solid fa-plus"></i> Add Product</button><a class="btn secondary" href="Admin/AdminDashboard.php">Cancel</a></div></form></section></main></div><script src="assets/dunkhome-ui.js?v=20261001-loader4" defer></script></body></html>

