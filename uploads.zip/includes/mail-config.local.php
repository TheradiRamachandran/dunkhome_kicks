<?php
declare(strict_types=1);

return [
  'DUNKHOME_MAIL_FROM' => 'Dunkhomekicks@gmail.com',
  'DUNKHOME_SMTP_HOST' => 'smtp.gmail.com',
  'DUNKHOME_SMTP_PORT' => '587',
  'DUNKHOME_SMTP_SECURE' => 'tls',
  'DUNKHOME_SMTP_USER' => 'Dunkhomekicks@gmail.com',
  'DUNKHOME_SMTP_PASS' => 'mbal zcml dgya ttku',
  'DUNKHOME_ADMIN_SETUP_KEY' => 'mbal zcml dgya ttku',
];